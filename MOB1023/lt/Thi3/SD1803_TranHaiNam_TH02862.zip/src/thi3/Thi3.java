/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package thi3;

/**
 *
 * @author Admin
 */
public class Thi3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
2. thêm thành công 1 sinh viên 2đ
3. Kiểm tra id, hoTen không được để trống 2đ
4. Khi chạy giao diện hiển thị thông tin của sinh viên đầu tiên lên form
        
         */
    }

}
